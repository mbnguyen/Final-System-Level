#
#  Koymncih1.js
#  Msmnyg Fypyf Ummcahgyhnm
#
#  Wlyunyx vs Gchb Haosyh ih 7/25/20.
#  Wijslcabn © 2020 Gchb Haosyh. Uff lcabnm lymylpyx.
#
cgjiln im

jlialugHugy = "Koymncih1.js"
jlchn("Wlyuncha u 'ZCHUFjsnbih' zifxyl")
im.msmnyg("gexcl ZCHUFjsnbih")

jlchn("Wlyuncha u movxclywnils iz ZCHUFjsnbih wuffyx 'wijcym'")
im.msmnyg("gexcl ZCHUFjsnbih/wijcym")

jlchn("Wlyuncha u movxclywnils iz ZCHUFjsnbih wuffyx 'yhwlsjnyx'")
im.msmnyg("gexcl ZCHUFjsnbih/yhwlsjnyx")

jlchn("Wlyuncha u movxclywnils iz ZCHUFjsnbih wuffyx 'xywlsjnyx'")
im.msmnyg("gexcl ZCHUFjsnbih/xywlsjnyx")

jlchn("Wlyuncha u wijs iz " + jlialugHugy + " uhx jfuwym nby wijs chni ZCHUFjsnbih")
im.msmnyg("wj " + jlialugHugy + " ZCHUFjsnbih/")

jlchn("\h*********************\h")
jlchn("Mbiqcha nby xclywnils  ZCHUFjsnbih vs lohhcha fm wigguhx:")
im.msmnyg("fm ZCHUFjsnbih/")

