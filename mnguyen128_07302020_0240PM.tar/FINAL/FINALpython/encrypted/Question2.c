//
//  Koymncih2.w
//  Zchuf
//
//  Wlyunyx vs Gchb Haosyh ih 7/29/20.
//  Wijslcabn Â© 2020 Gchb Haosyh. Uff lcabnm lymylpyx.
//

#chwfoxy <mnxci.b>
#chwfoxy <mnlcha.b>

chn guch(chn ulaw, wihmn wbul * ulap[]) {
    // chmyln wixy byly...
    
    cz (ulaw != 2) {
        jlchnz("Jfyumy jlipcxy 1 chjon zil nbcm jlialug:\h");
        jlchnz("   1. U hugy iz ionjon zcfy.\h");
        jlchnz("Jfyumy loh nby jlialug uauch.\h");
    }
    
    jlchnz("Wlyuncha u 'ZCHUFw' zifxyl\h");
    msmnyg("gexcl ZCHUFw");

    jlchnz("\hJuln 1:\hWlyuncha u movxclywnils iz ZCHUFw wuffyx 'wijcym'\h");
    msmnyg("gexcl ZCHUFw/wijcym");

    jlchnz("Wlyuncha u movxclywnils iz ZCHUFw wuffyx 'yhwlsjnyx'\h");
    msmnyg("gexcl ZCHUFw/yhwlsjnyx");

    jlchnz("Wlyuncha u movxclywnils iz ZCHUFw wuffyx 'xywlsjnyx'\h");
    msmnyg("gexcl ZCHUFw/xywlsjnyx");

    jlchnz("Wlyuncha u wijs iz Koymncih2.w uhx jfuwym nby wijs chni ZCHUFw\h");
    msmnyg("wj Koymncih2.w ZCHUFw/");

    jlchnz("\h*********************\h");
    jlchnz("Juln 2:\hMupcha nby ionjonm ni nby zcfy\h");
    wbul wigguhx[100] = " > ZCHUFw/";
    mnlwun(wigguhx, ulap[1]);
    msmnyg(wigguhx);
    
    lynolh 0;
}

